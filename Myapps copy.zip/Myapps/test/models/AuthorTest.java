package models;

import org.junit.Test;

import static org.junit.Assert.*;

public class AuthorTest {
 @Test
    public void testCreate(){
       final Author author=new Author(1,"Akhila","Akki");

 }


}